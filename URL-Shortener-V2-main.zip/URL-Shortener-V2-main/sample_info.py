# Mandatory variables for the bot to start
API_ID = 1234
API_HASH = 'bf05f7a4b4c89c44be6'
BOT_TOKEN = '5517520189:AAFeexxxxxxxxxxxxxxxxx'
ADMINS = [1861030649, 1798040070]
DATABASE_NAME = 'MdiskConvertor'
DATABASE_URL = 'mongodb+srv://username:pwd@cluster0.xxxx.mongodb.net/myFirstDatabase?retryWrites=true&w=majority'

#  Optionnal variables
CHANNELS = True
CHANNEL_ID = [-1001798040070, -1001194853986]
FORWARD_MESSAGE = True
SOURCE_CODE = 'https://github.com/kevinnadar22/URL-Shortener-V2'
BANNER_IMAGE = 'https://cdn.pixabay.com/photo/2019/04/24/21/55/cinema-4153289__480.jpg'
WELCOME_IMAGE = 'https://media.istockphoto.com/photos/hello-and-welcome-written-white-lightbox-sitting-on-blue-background-picture-id1371547852?b=1&k=20&m=1371547852&s=170667a&w=0&h=vRGvMO4a7KKYdTQ9Ln1UVdlg5C0POExw73jGsotVgzA='
LINK_BYPASS = False
HEROKU_API_KEY = 'dvetw-rde64b-2gsyww-ewef'
HEROKU_APP_NAME = 'MyHerokuApp'